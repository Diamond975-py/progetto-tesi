
variable "table_name" {}
